#!/bin/bash
python3 task4.py