#!/bin/bash
python3 task3.py