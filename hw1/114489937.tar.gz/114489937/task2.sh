#!/bin/bash
python3 task2.py