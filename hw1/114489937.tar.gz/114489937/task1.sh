#!/bin/bash
python3 task1.py